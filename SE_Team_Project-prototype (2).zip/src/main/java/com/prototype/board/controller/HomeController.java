package com.prototype.board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/dashboard")
    public String dashboard(Model model){
        return "dashboard";
    }

    @GetMapping("/settings")
    public String settings(Model model) {
        return "settings";
    }

    @GetMapping("/wiki")
    public String wiki(Model model) {
        return "wiki";
    }

    @GetMapping("/bug_submit")
    public String bugSubmit(Model model) {
        return "bug_submit";
    }

    @GetMapping("/bug_search")
    public String bugSearch(Model model) {
        return "bug_search";
    }

    @GetMapping("/register")
    public String register(Model model){
        return "register";
    }

    @GetMapping("/index")
    public String index(Model model) {
        return "index";
    }

    @GetMapping("/list")
    public String list(Model model){
        return "list";
    }
}

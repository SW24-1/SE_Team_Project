package com.prototype.board.controller;

import com.prototype.board.dto.BoardDTO;
import com.prototype.board.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@RequiredArgsConstructor
public class BoardController {
    private final BoardService boardService;

    @GetMapping("/{id}")
    public String findById(@PathVariable("id") Long id, Model model) {
        boardService.updateHits(id);
        BoardDTO boardDTO = boardService.findById(id);
        model.addAttribute("board", boardDTO);
        return "detail";
    }

    @GetMapping("/bug_submit")
    public String bugSubmit(Model model) {
        return "bug_submit";
    }

    @GetMapping("/bug_search")
    public String bugSearch(Model model) {
        return "bug_search";
    }

    @GetMapping("/wiki/create")
    public String documentCreate(Model model) {
        return "wiki/document_create"; // 수정된 경로
    }

    @GetMapping("/wiki/edit")
    public String editDocument(Model model) {
        return "wiki/edit_document"; // 수정된 경로
    }
}
